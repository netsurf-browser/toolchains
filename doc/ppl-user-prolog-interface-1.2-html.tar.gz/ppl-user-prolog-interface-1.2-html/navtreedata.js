var NAVTREE =
[
  [ "PPL Prolog Language Interface", "index.html", [
    [ "Prolog Language Interface", "index.html", null ],
    [ "GNU General Public License", "GPL_different_HTML_tag.html", null ],
    [ "GNU Free Documentation License", "GFDL_different_HTML_tag.html", null ],
    [ "System-Independent Features", "PI_SI_Features.html", null ],
    [ "Domains Predicates", "domains_predicates.html", null ],
    [ "Compilation and Installation", "PI_Compilation.html", null ],
    [ "Prolog Interface System-Dependent Features", "PI_SD_Features.html", null ],
    [ "Modules", "modules.html", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"GFDL_different_HTML_tag.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
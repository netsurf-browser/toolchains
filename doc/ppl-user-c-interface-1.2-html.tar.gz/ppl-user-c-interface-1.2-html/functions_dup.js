var functions_dup =
[
    [ "p", "functions.html", null ],
    [ "w", "functions_w.html", null ]
];
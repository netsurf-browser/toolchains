var NAVTREE =
[
  [ "PPL C Language Interface", "index.html", [
    [ "GNU General Public License", "GPL_different_HTML_tag.html", null ],
    [ "GNU Free Documentation License", "GFDL_different_HTML_tag.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Classes", null, [
      [ "Class List", "annotated.html", "annotated" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"GFDL_different_HTML_tag.html",
"group__PPL__CXX__interface.html#ggaa88e9b9cb2588cbf5914695fc14e69a8a4e2e7513e80017645e24e2fc7bb6846d",
"interfaceppl__Grid__Generator__tag.html#a9c2a70f5f90ec3da123f549d6ca9fe4a",
"interfaceppl__Polyhedron__tag.html#ab062917f016d95800e29f87c203fd3bb"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
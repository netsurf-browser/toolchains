var functions_func =
[
    [ "p", "functions_func.html", null ],
    [ "w", "functions_func_w.html", null ]
];
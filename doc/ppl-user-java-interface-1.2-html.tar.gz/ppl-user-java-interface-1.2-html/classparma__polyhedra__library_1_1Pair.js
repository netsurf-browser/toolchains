var classparma__polyhedra__library_1_1Pair =
[
    [ "getFirst", "classparma__polyhedra__library_1_1Pair.html#a0f022d23c55748a9e437e1625149bf5a", null ],
    [ "getSecond", "classparma__polyhedra__library_1_1Pair.html#a35e4df2723c110fbdadbcde7fe9cfae0", null ]
];
var NAVTREE =
[
  [ "PPL Java Language Interface", "index.html", [
    [ "GNU General Public License", "GPL_different_HTML_tag.html", null ],
    [ "GNU Free Documentation License", "GFDL_different_HTML_tag.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ]
    ] ],
    [ "Classes", null, [
      [ "Class List", "annotated.html", "annotated" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"GFDL_different_HTML_tag.html",
"classparma__polyhedra__library_1_1Polyhedron.html#a110353a7864529b85d5465ac1bce2670",
"group__PPL__CXX__interface.html#gga113f1e845cba6b1c3c5705d0e14f1cc1a40409716eac06f7ee5c44a200d3702f0"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';
var modules =
[
    [ "Java Language Interface", "group__PPL__Java__interface.html", "group__PPL__Java__interface" ],
    [ "C++ Language Interface", "../ppl-user-1.2-html/group__PPL__CXX__interface.html", "group__PPL__CXX__interface" ]
];
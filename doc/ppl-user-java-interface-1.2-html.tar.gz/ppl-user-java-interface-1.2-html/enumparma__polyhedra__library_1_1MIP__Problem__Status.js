var enumparma__polyhedra__library_1_1MIP__Problem__Status =
[
    [ "UNFEASIBLE_MIP_PROBLEM", "enumparma__polyhedra__library_1_1MIP__Problem__Status.html#a417470c5917175d267ea3ec71df18027", null ],
    [ "UNBOUNDED_MIP_PROBLEM", "enumparma__polyhedra__library_1_1MIP__Problem__Status.html#af2bdcebf7178739216e2dc7f5c421c9c", null ]
];
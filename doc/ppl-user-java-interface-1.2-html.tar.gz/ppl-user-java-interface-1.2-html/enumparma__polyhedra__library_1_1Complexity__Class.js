var enumparma__polyhedra__library_1_1Complexity__Class =
[
    [ "POLYNOMIAL_COMPLEXITY", "enumparma__polyhedra__library_1_1Complexity__Class.html#a5c1b244e9422e1c29c71844a9f896aee", null ],
    [ "SIMPLEX_COMPLEXITY", "enumparma__polyhedra__library_1_1Complexity__Class.html#a00d82d93d2d0113f1ea5b615decb2849", null ]
];
var enumparma__polyhedra__library_1_1Bounded__Integer__Type__Overflow =
[
    [ "OVERFLOW_WRAPS", "enumparma__polyhedra__library_1_1Bounded__Integer__Type__Overflow.html#a1834eabb1a60cd21454609bb6af2b70c", null ],
    [ "OVERFLOW_UNDEFINED", "enumparma__polyhedra__library_1_1Bounded__Integer__Type__Overflow.html#a20f960ad44478ccbccc6ba807c88ec88", null ]
];
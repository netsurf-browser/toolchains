var NAVTREE =
[
  [ "PPL", "index.html", [
    [ "General Information on the PPL", "index.html", [
      [ "The Main Features", "index.html#preamble", [
        [ "Semantic Geometric Descriptors", "index.html#Semantic_Geometric_Descriptors", null ],
        [ "Syntactic Geometric Descriptors", "index.html#Syntactic_Geometric_Descriptors", [
          [ "Basic Geometric Descriptors", "index.html#Basic_Geometric_Descriptors", null ],
          [ "Constraint Geometric Descriptors", "index.html#Constraint_Geometric_Descriptors", null ],
          [ "Generator Geometric Descriptors", "index.html#Generator_Geometric_Descriptors", null ]
        ] ],
        [ "Generic Operations on Semantic Geometric Descriptors", "index.html#Generic_Operations_on_Semantic_Geometric_Descriptors", null ]
      ] ],
      [ "Upward Approximation", "index.html#Upward_Approximation", null ],
      [ "Approximating Integers", "index.html#Approximating_Integers", [
        [ "Dropping Non-Integer Points", "index.html#Dropping_Non_Integer_Points", null ],
        [ "Approximating Bounded Integers", "index.html#Approximating_Bounded_Integers", [
          [ "Wrapping Operator", "index.html#Wrapping_Operator", null ]
        ] ]
      ] ],
      [ "Convex Polyhedra", "index.html#convex_polys", [
        [ "Vectors, Matrices and Scalar Products", "index.html#Vectors_Matrices_and_Scalar_Products", null ],
        [ "Affine Hyperplanes and Half-spaces", "index.html#Affine_Hyperplanes_and_Half_spaces", null ],
        [ "Convex Polyhedra", "index.html#Convex_Polyhedra", null ],
        [ "Bounded Polyhedra", "index.html#Bounded_Polyhedra", null ]
      ] ],
      [ "Representations of Convex Polyhedra", "index.html#representation", [
        [ "Constraints Representation", "index.html#Constraints_Representation", null ],
        [ "Combinations and Hulls", "index.html#Combinations_and_Hulls", null ],
        [ "Points, Closure Points, Rays and Lines", "index.html#Points_Closure_Points_Rays_and_Lines", null ],
        [ "Generators Representation", "index.html#Generators_Representation", null ],
        [ "Minimized Representations", "index.html#Minimized_Representations", null ],
        [ "Double Description", "index.html#Double_Description", null ],
        [ "Topologies and Topological-compatibility", "index.html#Topologies_and_Topological_compatibility", null ],
        [ "Space Dimensions and Dimension Compatibility", "index.html#Space_Dimensions_and_Dimension_Compatibility", null ],
        [ "Affine Independence and Affine Dimension", "index.html#Affine_Independence_and_Affine_Dimension", null ],
        [ "Rational Polyhedra", "index.html#Rational_Polyhedra", null ]
      ] ],
      [ "Operations on Convex Polyhedra", "index.html#Operations_on_Convex_Polyhedra", [
        [ "Intersection and Convex Polyhedral Hull", "index.html#Intersection_and_Convex_Polyhedral_Hull", null ],
        [ "Convex Polyhedral Difference", "index.html#Convex_Polyhedral_Difference", null ],
        [ "Concatenating Polyhedra", "index.html#Concatenating_Polyhedra", null ],
        [ "Adding New Dimensions to the Vector Space", "index.html#Adding_New_Dimensions_to_the_Vector_Space", null ],
        [ "Removing Dimensions from the Vector Space", "index.html#Removing_Dimensions_from_the_Vector_Space", null ],
        [ "Mapping the Dimensions of the Vector Space", "index.html#Mapping_the_Dimensions_of_the_Vector_Space", null ],
        [ "Expanding One Dimension of the Vector Space to Multiple Dimensions", "index.html#Expanding_One_Dimension_of_the_Vector_Space_to_Multiple_Dimensions", null ],
        [ "Folding Multiple Dimensions of the Vector Space into One Dimension", "index.html#Folding_Multiple_Dimensions_of_the_Vector_Space_into_One_Dimension", null ],
        [ "Images and Preimages of Affine Transfer Relations", "index.html#Images_and_Preimages_of_Affine_Transfer_Relations", null ],
        [ "Single-Update Affine Functions.", "index.html#Single_Update_Affine_Functions", null ],
        [ "Single-Update Bounded Affine Relations.", "index.html#Single_Update_Bounded_Affine_Relations", null ],
        [ "Affine Form Relations.", "index.html#affine_form_relation", null ],
        [ "Generalized Affine Relations.", "index.html#Generalized_Affine_Relations", null ],
        [ "Cylindrification Operator", "index.html#Cylindrification", null ],
        [ "Time-Elapse Operator", "index.html#Time_Elapse_Operator", null ],
        [ "Positive Time-Elapse Operator", "index.html#Positive_Time_Elapse_Operator", null ],
        [ "Meet-Preserving Enlargement and Simplification", "index.html#Meet_Preserving_Simplification", null ],
        [ "Relation-With Operators", "index.html#Relation_With_Operators", null ],
        [ "Widening Operators", "index.html#Widening_Operators", null ],
        [ "Widening with Tokens", "index.html#Widening_with_Tokens", null ],
        [ "Extrapolation Operators", "index.html#Extrapolation_Operators", null ]
      ] ],
      [ "Intervals and Boxes", "index.html#Intervals_and_Boxes", [
        [ "Widening and Extrapolation Operators on Boxes", "index.html#Widening_and_Extrapolation_Operators_on_Boxes", null ]
      ] ],
      [ "Weakly-Relational Shapes", "index.html#Weakly_Relational_Shapes", [
        [ "Bounded Difference Shapes", "index.html#Bounded_Difference_Shapes", null ],
        [ "Octagonal Shapes", "index.html#Octagonal_Shapes", null ],
        [ "Weakly-Relational Shapes Interface", "index.html#Weakly_Relational_Shape_Interface", null ],
        [ "Widening and Extrapolation Operators on Weakly-Relational Shapes", "index.html#Widening_and_Extrapolation_Operators_on_WR_Shapes", null ]
      ] ],
      [ "Rational Grids", "index.html#sect_rational_grids", [
        [ "Congruences and Congruence Relations", "index.html#Congruence_Relations", null ],
        [ "Rational Grids", "index.html#Rational_Grids", null ],
        [ "Integer Combinations", "index.html#Integer_Combinations", null ],
        [ "Points, Parameters and Lines", "index.html#Points_Parameters_Lines", null ],
        [ "The Grid Generator Representation", "index.html#Grid_Generator_Representation", null ],
        [ "Minimized Grid Representations", "index.html#Grid_Minimized_Representations", null ],
        [ "Double Description for Grids", "index.html#Grids_Double_Description_Grids", null ],
        [ "Space Dimensions and Dimension-compatibility for Grids", "index.html#Grid_Space_Dimensions", null ],
        [ "Affine Independence and Affine Dimension for Grids", "index.html#Grid_Affine_Dimension", null ]
      ] ],
      [ "Operations on Rational Grids", "index.html#rational_grid_operations", [
        [ "Affine Images and Preimages", "index.html#Grid_Affine_Transformation", null ],
        [ "Generalized Affine Images", "index.html#Grid_Generalized_Image", null ],
        [ "Frequency Operator", "index.html#Grid_Frequency", null ],
        [ "Time-Elapse Operator", "index.html#Grid_Time_Elapse", null ],
        [ "Relation-with Operators", "index.html#Grid_Relation_With", null ],
        [ "Wrapping Operator", "index.html#Grid_Wrapping_Operator", null ],
        [ "Widening Operators", "index.html#Grid_Widening", null ],
        [ "Widening with Tokens", "index.html#Grid_Widening_with_Tokens", null ],
        [ "Extrapolation Operators", "index.html#Grid_Extrapolation", null ]
      ] ],
      [ "The Powerset Construction", "index.html#powerset", [
        [ "The Powerset Domain", "index.html#The_Powerset_Domain", null ]
      ] ],
      [ "Operations on the Powerset Construction", "index.html#ps_operations", [
        [ "Meet and Upper Bound", "index.html#Meet_and_Upper_Bound", null ],
        [ "Adding a Disjunct", "index.html#Adding_a_Disjunct", null ],
        [ "Collapsing a Powerset Element", "index.html#Collapsing_a_Powerset_Element", null ]
      ] ],
      [ "The Pointset Powerset Domain", "index.html#pointset_powerset", [
        [ "Meet-Preserving Simplification", "index.html#Powerset_Meet_Preserving_Simplification", null ],
        [ "Geometric Comparisons", "index.html#Geometric_Comparisons", null ],
        [ "Pairwise Merge", "index.html#Pairwise_Merge", null ],
        [ "Powerset Extrapolation Operators", "index.html#Powerset_Extrapolation_Operators", null ],
        [ "Certificate-Based Widenings", "index.html#Certificate_Based_Widenings", null ]
      ] ],
      [ "Analysis of floating point computations", "index.html#floating_point", [
        [ "Linear forms with interval coefficients", "index.html#interval_linear_forms", null ],
        [ "Use of other abstract domains for floating point analysis", "index.html#fp_abstract_domains", null ]
      ] ],
      [ "Using the Library", "index.html#use_of_library", [
        [ "A Note on the Implementation of the Operators", "index.html#A_Note_on_the_Implementation_of_the_Operators", null ],
        [ "On Pointset_Powerset and Partially_Reduced_Product Domains: A Warning", "index.html#On_Pointset_Powerset_and_Partially_Reduced_Product_Domains_A_Warning", null ],
        [ "On Object-Orientation and Polymorphism: A Disclaimer", "index.html#On_Object_Orientation_and_Polymorphism_A_Disclaimer", null ],
        [ "On Const-Correctness: A Warning about the Use of References and Iterators", "index.html#On_Const_Correctness_A_Warning_about_the_Use_of_References_and_Iterators", null ]
      ] ],
      [ "Bibliography", "index.html#bibliography", null ]
    ] ],
    [ "GNU General Public License", "GPL.html", null ],
    [ "GNU Free Documentation License", "GFDL.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Variables", "namespacemembers_vars.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Classes", null, [
      [ "Class List", "annotated.html", "annotated" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ],
        [ "Related Functions", "functions_rela.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
".html",
"classParma__Polyhedra__Library_1_1Box.html#acddbfcdd0e7dd70c2258493ef67d0911",
"classParma__Polyhedra__Library_1_1Congruence.html#adeee840f3313b6050d439dbe5fe2fdd7",
"classParma__Polyhedra__Library_1_1Difference__Floating__Point__Expression.html#ab156f789e720f2d04086a672448ded40",
"classParma__Polyhedra__Library_1_1Grid.html#ac418d88df400bcd2233fb6281debb08f",
"classParma__Polyhedra__Library_1_1Linear__Expression.html#a298a32e26d8133869f28560cca4ba73b",
"classParma__Polyhedra__Library_1_1NNC__Polyhedron.html#a163f5dff452c6cf2e3a0c929eb2b8187",
"classParma__Polyhedra__Library_1_1PIP__Tree__Node.html#a740610ebd6849a2b7058991fa52071f8",
"classParma__Polyhedra__Library_1_1Poly__Con__Relation.html#ab9da0d811233cfb64481a7fe08b7f645",
"classParma__Polyhedra__Library_1_1Variables__Set.html#a6e710cc6607e4ec2791b182707bb4f1f",
"index.html#Adding_New_Dimensions_to_the_Vector_Space"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';